﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Common.Entities
{
	[Table("TemplateItem", Schema = "dbo")]
	public class TemplateItem
	{
		public int Id { get; set; }
        public string Name { get; set; } 
	 
		public int TemplateId { get; set; } 
 
	}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Entities
{
    [Table("Template", Schema = "dbo")]
    public class Template
    {
        public int Id { get; set; }
      
        public   string Name { get; set; }
        public virtual ICollection<TemplateItem> TemplateItems { get; set; } 
    }
}

﻿namespace Common.ExpressionPolicy
{
  
    using System;
    using System.Linq.Expressions;

    public static class ExpressionPolicy
    {
       
    }
}

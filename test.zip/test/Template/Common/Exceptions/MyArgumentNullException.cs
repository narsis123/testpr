﻿using System;

namespace Common.Exceptions
{
    public class MyArgumentNullException : ArgumentNullException
    { 
        public ErrorType RuleId { get; set; } 
        public MyArgumentNullException(ErrorType rule)
        {
            this.RuleId = rule;
        } 
    }
}
﻿using System.ComponentModel;

namespace Common.Exceptions
{
    public enum ErrorType
    {
        [Description("متن خطا")]
        TemplateDto_IsEmpty = 2001,
       
    }
}
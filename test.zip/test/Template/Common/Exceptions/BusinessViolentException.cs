﻿using System;

namespace Common.Exceptions
{
    public class BusinessManualyMessageException : Exception
    {
        public int RuleId { get; set; }
        public string Message { get; set; }
        public BusinessManualyMessageException(int ruleId, string message)
        {
            RuleId = ruleId;
            Message = message; 
        }
    }
}
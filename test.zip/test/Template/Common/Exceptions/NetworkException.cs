﻿using System;

namespace Common.Exceptions
{
    public class NetworkException:Exception
    {
        public ErrorType RuleId { get; set; }
        public NetworkException(ErrorType ruleId)
        {
            RuleId = ruleId;
        }
    }}
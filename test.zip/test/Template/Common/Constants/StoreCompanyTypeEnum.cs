﻿namespace Common
{
    public enum StoreCompanyTypeEnum
    {
        Sale = 1,
        Buy = 2, 
    }
} 
﻿namespace Common
{
    public enum MerchandiseUnitType
    {
        UnKnown = 1,
        Numeral = 2,
    }
}
 
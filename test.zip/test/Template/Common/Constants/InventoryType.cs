﻿namespace Common
{
    public enum InventoryType
    {
        Increase = 1,
        Decrease = 2
    }
}
 
﻿using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;

namespace Composition.Installer
{
    public class HttpEndpointInstaller : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(Classes.FromAssemblyNamed("TemplateEndPoint")
                .Pick()
                .WithService
                .DefaultInterfaces()
                .LifestyleTransient()
            );
        }
    }
}

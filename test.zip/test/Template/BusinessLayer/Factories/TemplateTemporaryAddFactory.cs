﻿using BusinessLayer.DTO;
using Common.Entities;
using Common.Tools;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BusinessLayer.Factories
{
    public class TemplateTemporaryAddFactory : ITemplateAddFactory
    {
        private ITemplateItemAddFactory templateItemFactory;

        public TemplateTemporaryAddFactory(ITemplateItemAddFactory templateItemFactory)
        {
            this.templateItemFactory = templateItemFactory;
        }

        public Template ConvertToAddTemporaryProcurment(TemplateAddDto procurmentDto)
        {
            Template template = new Template();
            template.Id= procurmentDto.Id;
            template.Name = procurmentDto.Name;
            template.TemplateItems = templateItemFactory.ConvertToAddTemplateItems(procurmentDto.Items).ToList();


            return template;
        }

     

        public TemplateDto ConvertToProcurmentDto(Template procurment)
        {


            var procurmentDto = ObjectEx.ShallowCopy<TemplateDto>(procurment);
            var templateItems = templateItemFactory.ConvertToProcurmentItemDto(procurment.TemplateItems); 
            procurmentDto.TemplateItems = templateItems;

            return procurmentDto;
        }

         
    }
}

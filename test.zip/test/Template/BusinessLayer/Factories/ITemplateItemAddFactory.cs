﻿using BusinessLayer.DTO;
using Common.Entities;
using System.Collections.Generic;

namespace BusinessLayer.Factories
{
    public interface ITemplateItemAddFactory
    {
        IEnumerable<TemplateItemDto> ConvertToProcurmentItemDto(IEnumerable<TemplateItem> enumerable);
        IEnumerable<TemplateItem> ConvertToAddTemplateItems(IEnumerable<TemplateItemAddDto> templateItemDtos);
    }
}

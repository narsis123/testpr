﻿using BusinessLayer.DTO;
using Common.Entities;
using Common.Tools;
using System.Collections.Generic;
using System.Linq;

namespace BusinessLayer.Factories
{
    public class TemplateItemFactory : ITemplateItemAddFactory
    {
        public IEnumerable<TemplateItem> ConvertToAddTemplateItems(IEnumerable<TemplateItemAddDto> templateItemAddDtos)
        {
            return templateItemAddDtos.Select(a=> ConvertToAddTemplateItem(a));
        }
        public TemplateItem ConvertToAddTemplateItem(TemplateItemAddDto templateItemAddDto)
        {
            TemplateItem item = new TemplateItem();
            item.Name = templateItemAddDto.Name;
            item.Id= templateItemAddDto.Id;


            return item;
        }
        public IEnumerable<TemplateItemDto> ConvertToProcurmentItemDto(IEnumerable<TemplateItem> templateItems)
        {
           return ObjectEx.ShallowCopy<TemplateItemDto>(templateItems);
        }
    }
}

﻿using BusinessLayer.DTO;
using Common.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Factories
{
    public interface ITemplateAddFactory
    {
        TemplateDto ConvertToProcurmentDto(Template procurment);
        Template ConvertToAddTemporaryProcurment(TemplateAddDto procurmentDto);
    }
}

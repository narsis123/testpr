﻿namespace BusinessLayer.DTO
{
	public class TemplateItemAddDto : TemplateItemDto
	{

	}
}
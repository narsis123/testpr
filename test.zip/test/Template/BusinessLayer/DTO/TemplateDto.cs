﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.DTO
{
  
    public class TemplateDto  
    {
        public int Id { get; set; }
        public int Name { get; set; }
      
        public IEnumerable<TemplateItemDto> TemplateItems { get; set; }
    }
}

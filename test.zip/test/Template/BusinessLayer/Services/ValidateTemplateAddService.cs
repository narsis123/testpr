﻿using BusinessLayer.DTO;
using Common.Exceptions;
using DataAccess;
using System;
using System.Linq;

namespace BusinessLayer.Services
{

    public class ValidateTemplateAddService : IValidateTemplateAddService
    {
        private IUnitOfWork unitOfWork;
        private TemplateAddDto templateDto;

        public ValidateTemplateAddService(IUnitOfWork unitOfWork, TemplateAddDto templateDto)
        {
            this.unitOfWork = unitOfWork;
            this.templateDto = templateDto;
        }

        public void Check()
        {
            if (templateDto.Id <= 0)
            {
                throw new BusinessException(ErrorType.TemplateDto_IsEmpty);

            } 
         
            
        }

       
    }
}

﻿using BusinessLayer.DTO;
using BusinessLayer.Factories;
using Common;
using Common.Entities;
using Common.Exceptions;
using Common.Tools;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BusinessLayer.Services
{
    public class TemplateService : ITemplateService
    {
        private readonly IUnitOfWork unitOfWork;
        private ITemplateAddFactory templateFactory;
    
 


        public TemplateService(IUnitOfWork unitOfWork, ITemplateAddFactory templateFactory)
        {
            this.unitOfWork = unitOfWork;
            this.templateFactory = templateFactory;
        }

        public TemplateDto Add(TemplateAddDto templateAddDto)
        {
            if (templateAddDto == null)
            {
                throw new MyArgumentNullException(ErrorType.TemplateDto_IsEmpty);
            }

            CheckTemplateAddValidation(templateAddDto);
   


      
      
            Template entity = templateFactory.ConvertToAddTemporaryProcurment(templateAddDto);
          
            unitOfWork.TemplateRepository.Add(entity);
            unitOfWork.Commit();
            var procurmentSavedId = entity.Id;
            return Get(procurmentSavedId);
        }
       
       

        private void CheckTemplateAddValidation(TemplateAddDto procurmentDto)
        {
            IValidateTemplateAddService validateTemplateAddService;
            validateTemplateAddService = new ValidateTemplateAddService(unitOfWork, procurmentDto);
            validateTemplateAddService.Check();
        }

        public TemplateDto Get(int id)
        {
            var entity = unitOfWork.TemplateRepository.Get(id);
            if (entity == null)
            {
                throw new EntityNotFoundException(ErrorType.TemplateDto_IsEmpty);
            }
            return templateFactory.ConvertToProcurmentDto(entity);
        }

        public IEnumerable<TemplateDto> GetAll()
        {
            var entites = unitOfWork.TemplateRepository.Get().ToList();
            return entites.Where(procurment =>   procurment.TemplateItems != null ).Select(templateFactory.ConvertToProcurmentDto);



        }
    }
}
﻿namespace BusinessLayer.Services
{
    public interface ITemplateItemService
    {
    }
}

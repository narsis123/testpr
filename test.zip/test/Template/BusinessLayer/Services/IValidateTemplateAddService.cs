﻿namespace BusinessLayer.Services
{
public interface IValidateTemplateAddService
{
    void Check();
}
}
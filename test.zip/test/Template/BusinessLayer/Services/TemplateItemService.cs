﻿namespace BusinessLayer.Services
{
    public class TemplateItemService:ITemplateItemService
    {
    }
}

﻿

using BusinessLayer.DTO;
using BusinessLayer.Services;
using Common.Exceptions;
using Common.Tools;
using System.Collections.Generic;
using System.Web.Http;

namespace TemplateWebApi2.Controllers
{
    [RoutePrefix("api/template")]
    public class TemplateController : ApiController
    {
        private readonly ITemplateService templateService;

        public TemplateController(ITemplateService templateService)
        {
            this.templateService = templateService;
        }

        [Route("")]
        public IHttpActionResult Get()
        {
            try
            {
                var dtos = templateService.GetAll();
                return Ok(dtos);
            }
            catch (EntityNotFoundException)
            {
                return NotFound();
            }
        }

        // GET api/procurments/5
        public IHttpActionResult Get(int id)
        {

            try
            {
                var dto = templateService.Get(id);
                return Ok(dto);
            }
            catch (EntityNotFoundException)
            {
                return NotFound();
            }
        }

        // POST api/procurments
        public IHttpActionResult Post([FromBody] TemplateAddDto templateDto)
        {

            try
            {
                var result = templateService.Add(templateDto);
                return Ok(result);
            }
            catch (MyArgumentNullException e)
            {
                return Content(System.Net.HttpStatusCode.BadRequest, new KeyValuePair<string, string>(e.RuleId.GetEnumDescription(), ((int)e.RuleId).ToString()));
            }
            catch (DatabaseException e)
            {
                return Content(System.Net.HttpStatusCode.BadRequest, new KeyValuePair<string, string>(e.RuleId.GetEnumDescription(), ((int)e.RuleId).ToString()));
            }
            catch (NetworkException e)
            {
                return Content(System.Net.HttpStatusCode.BadRequest, new KeyValuePair<string, string>(e.RuleId.GetEnumDescription(), ((int)e.RuleId).ToString()));
            }
            catch (EntityNotFoundException e)
            {
                return Content(System.Net.HttpStatusCode.NotFound, new KeyValuePair<string, string>(e.RuleId.GetEnumDescription(), ((int)e.RuleId).ToString()));
            }
            catch (BusinessException e)
            {
                return Content(System.Net.HttpStatusCode.BadRequest, new KeyValuePair<string, string>(e.RuleId.GetEnumDescription(), ((int)e.RuleId).ToString()));
            }
            catch (BusinessManualyMessageException e)
            {
                return Content(System.Net.HttpStatusCode.Conflict, new KeyValuePair<string, string>(e.Message, e.RuleId.ToString()));
            }
        }

        // PUT api/procurments/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/procurments/5
        public void Delete(int id)
        {
        }
    }
}

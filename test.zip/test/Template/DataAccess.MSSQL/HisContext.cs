﻿using Common.Entities;
using System;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace DataAccess.MSSQL
{
    public class HisContext : DbContext
    {
        public HisContext():base(GetConnectionStringName())
        {

        }

        private static string GetConnectionStringName()
        {
            return ConfigurationManager.AppSettings["AppConnectionName"];
        }

        public DbSet<Template> DbSetTemplate { get; set; }
        public DbSet<TemplateItem> DbSetTemplateItems { get; set; }
      

    
    }
}
   
 

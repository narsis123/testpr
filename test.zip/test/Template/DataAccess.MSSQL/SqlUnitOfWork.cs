﻿using System;
using System.Data.SqlClient;
using Common.Exceptions;
using Common.Tools;
using DataAccess.MSSQL.Exceptions;
using DataAccess.MSSQL.Repositories;
using DataAccess.Repositories;

namespace DataAccess.MSSQL
{
    public class SqlUnitOfWork : IUnitOfWork
    {
        private HisContext context;

        public SqlUnitOfWork()
        {
            var temp = typeof(System.Data.Entity.SqlServer.SqlFunctions);
            context = new HisContext();
        }

        public void Commit()
        {
            try
            {
                context.SaveChanges();
            }
            catch (SqlException ex)
            {
                throw new SqlExceptionFactory().Create(ex);
            }
            catch (Exception ex)
            {
                Tools.ManualErrorLog(context, ex, "SaveChanges", "SaveChanges");
                throw new DatabaseException( ErrorType.TemplateDto_IsEmpty);
            }
        }

        public void Dispose()
        {
            context?.Dispose();
        }

        private ITemplateRepository templateRepository;
        public ITemplateRepository TemplateRepository =>
            templateRepository ?? (templateRepository = new TemplateRepository(context));

        private ITemplateItemRepository templateItemRepository;
        public ITemplateItemRepository TemplateItemRepository =>
            templateItemRepository ?? (templateItemRepository = new TemplateItemRepository(context));

 
    }
}
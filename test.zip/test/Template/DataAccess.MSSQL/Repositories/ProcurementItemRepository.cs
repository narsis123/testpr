﻿using Common.Entities;
using DataAccess.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.MSSQL.Repositories
{
    public class TemplateItemRepository : ITemplateItemRepository
    {
        private readonly HisContext context;

        public TemplateItemRepository(HisContext context)
        {
            this.context = context;
        }

        public IEnumerable<TemplateItem> GetByTemplateId(int templateId)
        {
            return context.DbSetTemplateItems.Where(a => a.TemplateId == templateId);
        }
    }
}

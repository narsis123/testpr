﻿using Common.Entities;
using DataAccess.Repositories;
using System.Collections.Generic; 
using System.Linq;

namespace DataAccess.MSSQL.Repositories
{
    public class TemplateRepository : ITemplateRepository
    {
        private readonly HisContext context;

        public TemplateRepository(HisContext context)
        {
            this.context = context;
        }

        public void Add(Template entity)
        {
            context.DbSetTemplate.Add(entity);
            
        }

        public Template Get(int id)
        {
            return context.DbSetTemplate.Include("TemplateItems").FirstOrDefault(a=> a.Id==id);
        }

        public IEnumerable<Template> Get()
        {
            return context.DbSetTemplate.Include("TemplateItems");
        }

 
      
     
 
    }
}

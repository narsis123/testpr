﻿using System.Data.SqlClient;
using DataAccess.Exceptions;

namespace DataAccess.MSSQL.Exceptions
{
    public class SqlExceptionFactory
    {
        public DataBaseException Create(SqlException sqlException)
        {
            var isAuthenticationError = sqlException.Message.ToLower().Contains("login");
            if (isAuthenticationError)
                return new DatabaseConnectionException("Login failed", sqlException);
            if (sqlException.Message.ToLower().Contains("network"))
                return new DatabaseConnectionException("can not connect to database", sqlException);

            return new DataBaseException(sqlException.Message, sqlException);
        }
    }
}

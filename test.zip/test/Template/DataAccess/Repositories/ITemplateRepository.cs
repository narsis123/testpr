﻿using Common.Entities;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public interface ITemplateRepository
    {
        IEnumerable<Template> Get(); 
        void Add(Template entity);
        Template Get(int id);
    }
}

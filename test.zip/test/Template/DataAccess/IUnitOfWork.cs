﻿using DataAccess.Repositories;
using System;

namespace DataAccess
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit(); 
        ITemplateRepository TemplateRepository { get; }
        ITemplateItemRepository TemplateItemRepository { get; }
    
    }
}
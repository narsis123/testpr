﻿using System;
using System.Runtime.Serialization;

namespace DataAccess.Exceptions
{
    public class DataBaseException : SystemException
    {
        public DataBaseException()
        {
        }

        public DataBaseException(string message) : base(message)
        {
        }

        public DataBaseException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected DataBaseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}

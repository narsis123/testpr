﻿using System.Data.SqlClient;
using System.Runtime.Serialization;

namespace DataAccess.Exceptions
{
    public class DatabaseConnectionException : DataBaseException
    {
        public DatabaseConnectionException()
        {
        }

        public DatabaseConnectionException(string message) : base(message)
        {
        }
        public DatabaseConnectionException(string message, SqlException sqlException) : base(message, sqlException)
        {

        }
        protected DatabaseConnectionException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}